# -*- coding: utf-8 -*-
"""
Librería Xcodes para regex $pyFunction en addons Kodi
Muestra categorías y canales desde servidores Xtream Codes API.

Uso en XML:
    return xcodes.xcodes("http://server:port/player_api.php?username=USER&password=PASS")

- Si NO recibe cat_id: devuelve las categorías (envueltas en <items>).
- Si recibe cat_id: devuelve los canales de esa categoría (envueltos en <items>).
"""

import re
import requests
import urllib.parse

# ============================================================
# Utilidades
# ============================================================

def parse_api_url(api_url: str):
    """Extrae base_url, username y password desde la URL del player_api."""
    match = re.match(r"(https?://[^/]+)/player_api\.php\?username=([^&]+)&password=([^&]+)", api_url)
    if not match:
        raise ValueError("URL API inválida. Debe tener formato player_api.php?username=USER&password=PASS")
    base_url, user, pwd = match.groups()
    return base_url, user, pwd

def get_json(url: str):
    resp = requests.get(url, timeout=15)
    resp.raise_for_status()
    return resp.json()

# ============================================================
# API Xtream Codes
# ============================================================

def get_categories(api_url):
    base, user, pwd = parse_api_url(api_url)
    url = f"{base}/player_api.php?username={user}&password={pwd}&action=get_live_categories"
    return get_json(url)

def get_channels(api_url, category_id):
    base, user, pwd = parse_api_url(api_url)
    url = f"{base}/player_api.php?username={user}&password={pwd}&action=get_live_streams&category_id={category_id}"
    channels = get_json(url)
    # Agrega la URL completa del stream
    for ch in channels:
        ch["stream_url"] = f"{base}/live/{user}/{pwd}/{ch.get('stream_id','')}.m3u8"
    return channels

# ============================================================
# Generadores XML (con <items> wrapper)
# ============================================================

def make_category_list(api_url):
    """Genera XML <items> con todas las categorías (cada una crea un regex dinámico)."""
    try:
        cats = get_categories(api_url)
        items = ""
        for c in cats:
            name = c.get("category_name", "Sin nombre")
            cid = c.get("category_id", "")
            # El link usa $doregex para ejecutar otra llamada que filtrará la categoría
            # IMPORTANTE: llamamos a la función xcodes.xcodes(...) desde el módulo
            link = f"$doregex[cat_{cid}]"
            items += f"""
<item>
  <title>{escape_xml(name)}</title>
  <link>NA</link>
  <externallink>{link}</externallink>
  <thumbnail>https://bgaddon.pro/black/img/television.png</thumbnail>
  <regex>
    <name>cat_{cid}</name>
    <expres><![CDATA[#$pyFunction
def GetLSProData(page_data, Cookie_Jar, m):
    from resources.lib import xcodes
    return xcodes.xcodes("{api_url}", cat_id="{cid}")
]]></expres>
    <page></page>
  </regex>
</item>
"""
        return f"<items>{items}</items>"
    except Exception as e:
        return f"<items><item><title>Error cargando categorías: {escape_xml(str(e))}</title><link>NA</link></item></items>"

def make_channel_list(api_url, cat_id):
    """Genera XML <items> con los canales de la categoría especificada."""
    try:
        chans = get_channels(api_url, cat_id)
        items = ""
        for c in chans:
            name = c.get("name", "Sin nombre")
            logo = c.get("stream_icon", "")
            stream_url = c.get("stream_url", "")
            items += f"""
<item>
  <title>{escape_xml(name)}</title>
  <link>{escape_xml(stream_url)}</link>
  <thumbnail>{escape_xml(logo)}</thumbnail>
</item>
"""
        return f"<items>{items}</items>"
    except Exception as e:
        return f"<items><item><title>Error cargando canales: {escape_xml(str(e))}</title><link>NA</link></item></items>"

# ============================================================
# Entrada principal para $pyFunction
# ============================================================

def xcodes(api_url, cat_id=None):
    """Punto de entrada para usar desde $pyFunction en XML."""
    if cat_id:
        return make_channel_list(api_url, cat_id)
    else:
        return make_category_list(api_url)

# ============================================================
# Helpers
# ============================================================

def escape_xml(text):
    """Escapa caracteres especiales para XML básico."""
    if text is None:
        return ""
    return (text.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace('"', "&quot;")
                .replace("'", "&apos;"))
