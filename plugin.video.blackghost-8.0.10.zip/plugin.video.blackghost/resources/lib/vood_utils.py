# resources/lib/vood_utils.py

import re
import requests
import urllib3

# Desactiva advertencias de SSL si el servidor tiene errores en el certificado
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

def extraer_vood_m3u8(embed_url):
    """
    Extrae y devuelve la URL .m3u8 desde una página embed de https://voodc.com
    """

    try:
        session = requests.Session()
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
            'Referer': 'https://voodc.com/',
            'Origin': 'https://voodc.com',
            'Connection': 'Keep-Alive'
        }

        # Paso 1: Obtener HTML de la página embed
        html0 = session.get(embed_url, headers=headers, timeout=10, verify=False).text

        # Paso 2: Extraer script embebido
        script_match = re.search(r'src="(//voodc\.com/[^"]+)"', html0)
        if not script_match:
            return "script no encontrado"
        script_url = 'https:' + script_match.group(1)

        # Paso 3: Obtener JS que contiene el token
        html1 = session.get(script_url, headers=headers, timeout=10, verify=False).text
        channelKey = re.search(r'embedded\+.*?"(.*?)"', html1)
        if not channelKey:
            return "token no encontrado"

        token = channelKey.group(1)
        final_url = f"https://voodc.com/player/d/{token}"

        # Paso 4: Obtener contenido con la URL .m3u8
        html2 = session.get(final_url, headers=headers, timeout=10, verify=False).text
        m3u8_match = re.search(r"var\s+PlayS\s*=\s*'([^']+\.m3u8[^']*)'", html2)
        if not m3u8_match:
            return "no se encontró m3u8"

        return m3u8_match.group(1)

    except Exception as e:
        return f"Error: {str(e)}"
