# resources/lib/kodi_stream_utils.py

import re
import requests
import base64
import urllib3
import json
import urllib.parse



urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

def voodc_m3u8(embed_url):
    """Extrae la URL .m3u8 desde una página embed de voodc.com"""
    try:
        session = requests.Session()
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
            'Referer': 'https://voodc.com/',
            'Origin': 'https://voodc.com',
        }
        html0 = session.get(embed_url, headers=headers, timeout=10, verify=False).text
        script = re.search(r'src="(//voodc\.com/[^"]+)"', html0)
        if not script:
            return "script no encontrado"
        js_url = 'https:' + script.group(1)
        html1 = session.get(js_url, headers=headers, timeout=10, verify=False).text
        token = re.search(r'embedded\+.*?"(.*?)"', html1)
        if not token:
            return "token no encontrado"
        final_url = f"https://voodc.com/player/d/{token.group(1)}"
        html2 = session.get(final_url, headers=headers, timeout=10, verify=False).text
        m3u8 = re.search(r"var\s+PlayS\s*=\s*'([^']+\.m3u8[^']*)'", html2)
        return m3u8.group(1) if m3u8 else "no se encontró m3u8"
    except Exception as e:
        return f"ERROR: {str(e)}"


# resources/lib/kodi_stream_utils.py
def daddyhd_m3u8(channel_id,domain):
    """
    Devuelve el enlace M3U8 final del servidor DaddyHD (kondoplay.cfd)
    con headers Kodi incluidos para reproducir el stream.
    Actualizado según la versión del regex m3u8 más reciente.
    """
    import re, json, base64, traceback
    from urllib.parse import quote_plus, urlparse
    import requests, urllib3
    import xbmc

    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    try:
        # ---------- CONFIG ----------
        base = f"https://{domain}"
        page_url = f"{base}/premiumtv/daddyhd.php?id={quote_plus(channel_id)}"
        ua = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
              "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36")

        s = requests.Session()
        headers_html = {
            "User-Agent": ua,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "es-ES,es;q=0.9,en;q=0.8",
            "Connection": "keep-alive",
            "Referer": base + "/",
        }

        # ---------- OBTENER HTML ----------
        r = s.get(page_url, headers=headers_html, verify=False, timeout=15)
        r.raise_for_status()
        html = r.text

        # ---------- CHANNEL_KEY ----------
        m_ck = re.search(r'const\s+CHANNEL_KEY\s*=\s*"([^"]+)"', html)
        channel_key = m_ck.group(1) if m_ck else channel_id

        # ---------- DETECTAR VARIABLE BASE64 ----------
        m_bundle = re.search(
            r'const\s+([A-Za-z]{3,5})\s*=\s*"([A-Za-z0-9+/=]{100,})"', html
        )
        if not m_bundle:
            raise ValueError("❌ No se encontró ninguna constante base64 (IJXX, XKZK, etc.)")

        var_name, bundle = m_bundle.groups()

        # ---------- DECODIFICAR BUNDLE ----------
        decoded = base64.b64decode(bundle).decode("utf-8", "ignore")
        parts = json.loads(decoded)
        for k, v in parts.items():
            try:
                parts[k] = base64.b64decode(v).decode("utf-8", "ignore")
            except Exception:
                pass

        # ---------- CONSTRUIR auth_url ----------
        bx = [40, 60, 61, 33, 103, 57, 33, 57]
        sc = ''.join(chr(b ^ 73) for b in bx)
        host = "https://top2new.newkso.ru/"
        auth_url = (
            f"{host}{sc}?channel_id={quote_plus(channel_key)}&"
            f"ts={quote_plus(parts.get('b_ts',''))}&"
            f"rnd={quote_plus(parts.get('b_rnd',''))}&"
            f"sig={quote_plus(parts.get('b_sig',''))}"
        )

        headers_api = {"User-Agent": ua, "Referer": page_url, "Connection": "keep-alive"}
        try:
            s.get(auth_url, headers=headers_api, verify=False, timeout=10)
        except:
            pass

        # ---------- SERVER LOOKUP ----------
        lookup_url = f"https://{urlparse(page_url).netloc}/server_lookup.php?channel_id={channel_key}"
        lr = s.get(lookup_url, headers=headers_api, verify=False, timeout=15)
        lookup = lr.json() if lr.ok else {}
        server_key = lookup.get("server_key", "")

        # ---------- GENERAR M3U8 ----------
        if server_key == "top1/cdn" or not server_key:
            m3u8_url = f"https://top1.newkso.ru/top1/cdn/{channel_key}/mono.m3u8"
        else:
            m3u8_url = f"https://{server_key}new.newkso.ru/{server_key}/{channel_key}/mono.m3u8"

        # ---------- HEADERS KODI ----------
        referer = f'https://{urlparse(page_url).netloc}'
        headers_kodi = f"Referer={referer}/&Origin={referer}&Connection=Keep-Alive&User-Agent={ua}"

        return m3u8_url + "|" + headers_kodi

    except Exception as e:
        xbmc.log("❌ Error en daddyhd_m3u8: " + str(e) + " | " + traceback.format_exc(), xbmc.LOGERROR)
        return "plugin://plugin.video.blackghost/?error=" + quote_plus(str(e))


def streamglobal_m3u8(stream_url):
    """Extrae la URL .m3u8 desde streamtpglobal.com"""
    try:
        html = requests.get(stream_url, verify=False, timeout=10).text

        tp_match = re.search(r'playbackURL=""\,.*?=(\[\[.*?\]\]);', html, re.DOTALL)
        claves = re.search(r'{return\s(.*?)\;[\w\W\s]*?\{return\s(.*?)\;', html)
        if not tp_match or not claves:
            return "ERROR: No se encontró estructura JS"

        tp = eval(tp_match.group(1))
        tp.sort(key=lambda x: x[0])
        k = int(claves.group(1)) + int(claves.group(2))

        playback_url = ''
        for _, b64 in tp:
            try:
                decoded = base64.b64decode(b64).decode('utf-8')
                digits = ''.join(filter(str.isdigit, decoded))
                char_code = int(digits) - k
                playback_url += chr(char_code)
            except:
                continue
        return playback_url
    except Exception as e:
        return f"ERROR: {str(e)}"


def get_unpacked(page_data, pattern):
    """Extrae y desempaqueta JavaScript ofuscado (tipo eval(function(p,a,c,k,e,d)...))"""
    try:
        packed_match = re.search(pattern, page_data)
        if not packed_match:
            return "ERROR: no se encontró script ofuscado"

        from jsunpack import unpack
        unpacked = unpack(packed_match.group(1))
        return unpacked
    except Exception as e:
        return f"ERROR: {str(e)}"

# resources/lib/kodi_stream_utils.py

def play_jetextractors(url):
    """
    Wrapper para reproducir cualquier stream usando script.module.jetextractors.
    Recibe una URL (o lista de URLs) y reproduce directamente en Kodi.
    """
    try:
        from jetextractors import sportjetextractors
        import xbmcgui, xbmcplugin, sys

        urls = [url] if isinstance(url, str) else url

        # Ejecuta JetExtractors
        streams = sportjetextractors.play(urls)

        if not streams:
            xbmcgui.Dialog().ok("Error", "No se pudo extraer el stream")
            return

        # Reproducir cada stream (generalmente hay solo uno)
        for s in streams:
            list_item = xbmcgui.ListItem(label=s.get("name", "Stream"))
            list_item.setInfo('video', {'title': s.get("name", "Stream")})
            list_item.setPath(s["url"])
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, list_item)

    except ModuleNotFoundError:
        xbmcgui.Dialog().ok("Error", "script.module.jetextractors no está instalado")
    except Exception as e:
        xbmcgui.Dialog().ok("Error", f"No se pudo reproducir el stream: {str(e)}")